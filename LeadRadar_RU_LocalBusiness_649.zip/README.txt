LeadRadar — база локального бизнеса (OpenStreetMap)

Состав:
- leads_all.csv / leads_all.xlsx — все контакты
- Поля: name, phone, email, website, city, niche, address, координаты, osm_id

Источник: публичные данные OpenStreetMap (ODbL).
Использование: B2B-обзвон/квалификация лидов. Соблюдайте 38-ФЗ.

Продавец может собрать доп. город/нишу под заказ за 24 часа.
